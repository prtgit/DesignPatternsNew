package finalExam;

public interface Visitor {
	public void visit(Customer customer);

	public void visit(Order order);
}
