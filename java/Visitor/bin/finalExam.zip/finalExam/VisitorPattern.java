package finalExam;

import java.util.ArrayList;

public class VisitorPattern {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Customer> customers = new ArrayList<Customer>();
		
		Customer c1 = new Customer("Customer1");
		c1.addOrder(new Order("Order1", "Item1"));
		c1.addOrder(new Order("Order2", "Item1"));
		c1.addOrder(new Order("Order3", "Item1"));
		customers.add(c1);

		Customer c2 = new Customer("Customer2");
		Order o = new Order("Order_a");
		c2.addOrder(o);
		c2.addOrder(new Order("Order_b", "Item_b1"));
		customers.add(c2);

		GeneralReport visitor = new GeneralReport();

		for (Customer thisCustomer: customers){
			thisCustomer.accept(visitor);
		}

		visitor.displayResults();
	}
}
